package com.ifba.Repositriotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepositRioTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
